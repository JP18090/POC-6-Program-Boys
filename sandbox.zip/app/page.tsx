import Aforja from "./components/project.jsx";

export default function Home() {
  return (
    <main>
      <section>
        <Aforja></Aforja>
      </section>
    </main>
  );
}
